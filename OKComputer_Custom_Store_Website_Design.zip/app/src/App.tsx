import { CartProvider } from '@/context/CartContext';
import Navigation from '@/sections/Navigation';
import Hero from '@/sections/Hero';
import Services from '@/sections/Services';
import FeaturedServices from '@/sections/FeaturedServices';
import Portfolio from '@/sections/Portfolio';
import HowItWorks from '@/sections/HowItWorks';
import Testimonials from '@/sections/Testimonials';
import FAQ from '@/sections/FAQ';
import CTA from '@/sections/CTA';
import Footer from '@/sections/Footer';
import CartDrawer from '@/components/CartDrawer';
import './App.css';

function App() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-dark text-white relative overflow-x-hidden">
        {/* Grain Overlay */}
        <div className="grain-overlay" />

        {/* Navigation */}
        <Navigation />

        {/* Main Content */}
        <main>
          <Hero />
          <Services />
          <FeaturedServices />
          <Portfolio />
          <HowItWorks />
          <Testimonials />
          <FAQ />
          <CTA />
        </main>

        {/* Footer */}
        <Footer />

        {/* Cart Drawer */}
        <CartDrawer />
      </div>
    </CartProvider>
  );
}

export default App;
