import { Plus, Minus, ShoppingBag, Trash2, ArrowRight, Sparkles } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';

export default function CartDrawer() {
  const {
    items,
    removeFromCart,
    updateQuantity,
    totalItems,
    totalPrice,
    isCartOpen,
    setIsCartOpen,
    clearCart,
  } = useCart();

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent className="w-full sm:max-w-lg bg-dark-100 border-white/10 flex flex-col overflow-hidden">
        <SheetHeader className="border-b border-white/10 pb-4">
          <SheetTitle className="flex items-center gap-3 text-white">
            <div className="relative">
              <ShoppingBag className="w-6 h-6 text-coral" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 w-5 h-5 bg-coral rounded-full flex items-center justify-center text-xs font-bold text-white animate-pulse">
                  {totalItems}
                </span>
              )}
            </div>
            Your Cart
          </SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-coral/20 to-teal/20 flex items-center justify-center mb-6 animate-float">
              <ShoppingBag className="w-12 h-12 text-coral" />
            </div>
            <h3 className="font-display text-xl font-semibold text-white mb-2">
              Your cart is empty
            </h3>
            <p className="text-gray-400 mb-6">
              Discover amazing creative services and add them to your cart!
            </p>
            <Button
              onClick={() => setIsCartOpen(false)}
              className="bg-gradient-to-r from-coral to-teal text-white font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              Explore Services
            </Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-4 rounded-xl bg-dark-200 border border-white/5 hover:border-coral/30 transition-all duration-300 group"
                >
                  {/* Image */}
                  <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="font-display font-semibold text-white text-sm line-clamp-1 pr-2">
                        {item.name}
                      </h4>
                      {item.badge && (
                        <Badge className="text-xs bg-coral/20 text-coral border-coral/30">
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mb-2 line-clamp-1">
                      {item.description}
                    </p>
                    <div className="font-display font-bold text-coral">
                      ${item.price.toFixed(2)}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col items-end justify-between">
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-400/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-sm text-white font-medium">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-white/10 pt-4 space-y-4 bg-dark-100">
              {/* Summary */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Subtotal</span>
                  <span className="text-white">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Service Fee</span>
                  <span className="text-teal">Free</span>
                </div>
                <div className="flex justify-between text-lg font-semibold pt-2 border-t border-white/10">
                  <span className="text-white">Total</span>
                  <span className="font-display text-gradient">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <Button className="w-full bg-gradient-to-r from-coral to-teal text-white font-semibold rounded-xl py-6 group hover:opacity-90 transition-opacity">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Proceed to Checkout
                  <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
                </Button>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsCartOpen(false)}
                    className="flex-1 border-white/20 text-white hover:bg-white/10 rounded-xl"
                  >
                    Continue Shopping
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={clearCart}
                    className="text-gray-400 hover:text-red-400 hover:bg-red-400/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="flex justify-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-coral" />
                  Secure Checkout
                </span>
                <span>•</span>
                <span>Instant Delivery</span>
                <span>•</span>
                <span>Money Back</span>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
