import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Stars } from '@react-three/drei';
import * as THREE from 'three';

// Floating geometric shapes
function FloatingShapes() {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
      groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
    }
  });

  const shapes = useMemo(() => [
    { position: [-4, 2, -2], color: '#FF6B6B', scale: 0.8 },
    { position: [4, -1, -3], color: '#4ECDC4', scale: 0.6 },
    { position: [-3, -2, -1], color: '#45B7D1', scale: 0.7 },
    { position: [3, 3, -4], color: '#FFD700', scale: 0.5 },
    { position: [0, 4, -2], color: '#FF6B6B', scale: 0.4 },
    { position: [-2, -3, -3], color: '#4ECDC4', scale: 0.6 },
  ], []);

  return (
    <group ref={groupRef}>
      {shapes.map((shape, i) => (
        <Float
          key={i}
          speed={2}
          rotationIntensity={1}
          floatIntensity={2}
          position={shape.position as [number, number, number]}
        >
          <mesh scale={shape.scale}>
            {i % 3 === 0 ? (
              <boxGeometry args={[1, 1, 1]} />
            ) : i % 3 === 1 ? (
              <octahedronGeometry args={[0.7]} />
            ) : (
              <tetrahedronGeometry args={[0.8]} />
            )}
            <meshStandardMaterial
              color={shape.color}
              emissive={shape.color}
              emissiveIntensity={0.3}
              roughness={0.2}
              metalness={0.8}
            />
          </mesh>
        </Float>
      ))}
    </group>
  );
}

// Glowing orbs
function GlowingOrbs() {
  const orb1Ref = useRef<THREE.Mesh>(null);
  const orb2Ref = useRef<THREE.Mesh>(null);
  const orb3Ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    if (orb1Ref.current) {
      orb1Ref.current.position.x = Math.sin(time * 0.5) * 3;
      orb1Ref.current.position.y = Math.cos(time * 0.3) * 2;
    }
    if (orb2Ref.current) {
      orb2Ref.current.position.x = Math.cos(time * 0.4) * 4;
      orb2Ref.current.position.y = Math.sin(time * 0.6) * 1.5;
    }
    if (orb3Ref.current) {
      orb3Ref.current.position.x = Math.sin(time * 0.3) * -3;
      orb3Ref.current.position.y = Math.cos(time * 0.4) * 2.5;
    }
  });

  return (
    <>
      <mesh ref={orb1Ref} position={[0, 0, -5]}>
        <sphereGeometry args={[0.5, 32, 32]} />
        <MeshDistortMaterial
          color="#FF6B6B"
          emissive="#FF6B6B"
          emissiveIntensity={0.5}
          distort={0.4}
          speed={2}
          roughness={0}
        />
      </mesh>
      <mesh ref={orb2Ref} position={[2, 1, -6]}>
        <sphereGeometry args={[0.4, 32, 32]} />
        <MeshDistortMaterial
          color="#4ECDC4"
          emissive="#4ECDC4"
          emissiveIntensity={0.5}
          distort={0.3}
          speed={1.5}
          roughness={0}
        />
      </mesh>
      <mesh ref={orb3Ref} position={[-2, -1, -4]}>
        <sphereGeometry args={[0.3, 32, 32]} />
        <MeshDistortMaterial
          color="#45B7D1"
          emissive="#45B7D1"
          emissiveIntensity={0.5}
          distort={0.5}
          speed={2.5}
          roughness={0}
        />
      </mesh>
    </>
  );
}

// Particle field
function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null);
  
  const particles = useMemo(() => {
    const count = 200;
    const positions = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    
    return positions;
  }, []);

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[particles, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#ffffff"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
}

// Main scene
function Scene() {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#FF6B6B" />
      <pointLight position={[-10, -10, -10]} intensity={1} color="#4ECDC4" />
      <pointLight position={[0, 0, 5]} intensity={0.5} color="#45B7D1" />
      
      <Stars
        radius={50}
        depth={50}
        count={1000}
        factor={4}
        saturation={0}
        fade
        speed={1}
      />
      
      <FloatingShapes />
      <GlowingOrbs />
      <ParticleField />
    </>
  );
}

export default function Hero3DScene() {
  return (
    <div className="absolute inset-0 w-full h-full">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <Scene />
      </Canvas>
    </div>
  );
}
