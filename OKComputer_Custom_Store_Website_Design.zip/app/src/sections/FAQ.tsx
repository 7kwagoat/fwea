import { useState, useRef, useEffect } from 'react';
import { Plus, Minus, MessageCircle, Sparkles } from 'lucide-react';
import { faqs } from '@/data/services';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      id="faq"
      ref={sectionRef}
      className="py-24 relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-coral/10 rounded-full blur-[200px] -translate-y-1/2 pointer-events-none" />
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-teal/10 rounded-full blur-[200px] -translate-y-1/2 pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div 
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <Sparkles className="w-4 h-4 text-teal" />
              <span className="text-sm font-medium text-gray-300">FAQ</span>
            </div>
            
            <h2 
              className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              Frequently Asked <span className="text-gradient">Questions</span>
            </h2>
            
            <p 
              className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              Got questions? We&apos;ve got answers. If you can&apos;t find what you&apos;re looking for, 
              feel free to contact our support team.
            </p>
          </div>

          {/* FAQ Accordion */}
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={faq.id}
                className={`rounded-2xl border overflow-hidden transition-all duration-500 ${
                  openIndex === index
                    ? 'bg-dark-200 border-coral/50 shadow-glow'
                    : 'bg-dark-200/50 border-white/10 hover:border-white/20'
                } ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${300 + index * 100}ms` }}
              >
                {/* Question */}
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                >
                  <span className="font-display font-semibold text-white pr-4">
                    {faq.question}
                  </span>
                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                      openIndex === index
                        ? 'bg-gradient-to-r from-coral to-teal text-white rotate-180'
                        : 'bg-white/10 text-gray-400'
                    }`}
                  >
                    {openIndex === index ? (
                      <Minus className="w-4 h-4" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )}
                  </div>
                </button>

                {/* Answer */}
                <div
                  className={`overflow-hidden transition-all duration-500 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-5 sm:px-6 pb-5 sm:pb-6">
                    <p className="text-gray-400 leading-relaxed">{faq.answer}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Contact CTA */}
          <div 
            className={`mt-12 transition-all duration-700 delay-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 p-6 rounded-2xl bg-dark-200 border border-white/10">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-coral to-teal flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div className="text-center sm:text-left">
                <h3 className="font-display font-semibold text-white mb-1">
                  Still have questions?
                </h3>
                <p className="text-sm text-gray-400">
                  Our support team is here to help you 24/7.
                </p>
              </div>
              <a
                href="mailto:support@creteve.com"
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-coral to-teal text-white font-medium hover:opacity-90 transition-opacity whitespace-nowrap"
              >
                Contact Support
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
