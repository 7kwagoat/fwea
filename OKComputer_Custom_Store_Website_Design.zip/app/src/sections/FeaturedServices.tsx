import { useRef, useEffect, useState } from 'react';
import { ShoppingCart, Star, Check, Sparkles } from 'lucide-react';
import { services } from '@/data/services';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { use3DTilt } from '@/hooks/use3DTilt';

function ServiceCard({ service, index }: { service: typeof services[0]; index: number }) {
  const { addToCart } = useCart();
  const { ref, tilt, handlers } = use3DTilt(5);
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const getBadgeColor = (badge?: string) => {
    switch (badge) {
      case 'POPULAR':
        return 'bg-coral/20 text-coral border-coral/30';
      case 'BESTSELLER':
        return 'bg-gold/20 text-gold border-gold/30';
      case 'TRENDING':
        return 'bg-teal/20 text-teal border-teal/30';
      case 'PREMIUM':
        return 'bg-sky/20 text-sky border-sky/30';
      case 'QUICK':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div
      ref={cardRef}
      className={`transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div
        ref={ref}
        {...handlers}
        className="group relative h-full"
        style={{ perspective: '1000px' }}
      >
        <div
          className="relative h-full rounded-2xl overflow-hidden bg-dark-200 border border-white/10 transition-all duration-300 group-hover:border-coral/50"
          style={{
            transform: `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg) scale(${tilt.scale})`,
            transformStyle: 'preserve-3d',
            transition: 'transform 0.15s ease-out',
          }}
        >
          {/* Image */}
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={service.image}
              alt={service.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-200 via-transparent to-transparent" />
            
            {/* Badge */}
            {service.badge && (
              <Badge
                className={`absolute top-3 left-3 ${getBadgeColor(service.badge)} border`}
              >
                {service.badge}
              </Badge>
            )}
          </div>

          {/* Content */}
          <div className="p-5">
            {/* Rating */}
            <div className="flex items-center gap-1 mb-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3 h-3 ${
                      i < service.rating
                        ? 'text-gold fill-gold'
                        : 'text-gray-600'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs text-gray-500">({service.reviews})</span>
            </div>

            {/* Title */}
            <h3 className="font-display font-semibold text-white mb-1 line-clamp-1 group-hover:text-gradient transition-colors">
              {service.name}
            </h3>

            {/* Description */}
            <p className="text-sm text-gray-500 mb-3 line-clamp-2">
              {service.description}
            </p>

            {/* Features */}
            {service.features && (
              <div className="flex flex-wrap gap-1 mb-4">
                {service.features.slice(0, 3).map((feature, i) => (
                  <span
                    key={i}
                    className="text-xs px-2 py-1 rounded-full bg-white/5 text-gray-400 flex items-center gap-1"
                  >
                    <Check className="w-3 h-3 text-teal" />
                    {feature}
                  </span>
                ))}
              </div>
            )}

            {/* Price & CTA */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-lg text-white">
                  ${service.price}
                </span>
                {service.originalPrice && (
                  <span className="text-sm text-gray-500 line-through">
                    ${service.originalPrice}
                  </span>
                )}
              </div>
              <Button
                size="sm"
                onClick={() => addToCart(service)}
                className="bg-coral/20 hover:bg-coral text-coral hover:text-white border border-coral/30 rounded-lg transition-all duration-300"
              >
                <ShoppingCart className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function FeaturedServices() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="pricing"
      ref={sectionRef}
      className="py-24 relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-coral/5 to-transparent pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div 
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <Sparkles className="w-4 h-4 text-teal" />
              <span className="text-sm font-medium text-gray-300">Featured</span>
            </div>
            
            <h2 
              className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              Popular <span className="text-gradient">Services</span>
            </h2>
            
            <p 
              className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              Handpicked services loved by our community. Start your creative journey today.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {services.slice(0, 8).map((service, index) => (
              <ServiceCard key={service.id} service={service} index={index} />
            ))}
          </div>

          {/* View All Button */}
          <div 
            className={`text-center mt-12 transition-all duration-700 delay-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <Button
              size="lg"
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10 rounded-xl px-8"
            >
              View All Services
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
