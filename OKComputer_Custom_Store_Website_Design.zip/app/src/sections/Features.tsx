import { useRef, useEffect, useState } from 'react';
import { Clock, Shield, Headphones, Zap, Lock, Award } from 'lucide-react';

const features = [
  {
    id: '1',
    icon: Clock,
    title: 'Instant Delivery',
    description:
      'Get your products delivered instantly after payment confirmation. No waiting, start gaming right away.',
    color: 'purple',
  },
  {
    id: '2',
    icon: Shield,
    title: 'Secure Payment',
    description:
      'Your transactions are protected with industry-standard encryption. Shop with complete peace of mind.',
    color: 'teal',
  },
  {
    id: '3',
    icon: Headphones,
    title: '24/7 Support',
    description:
      'Our dedicated support team is available round the clock to assist you with any queries or issues.',
    color: 'purple',
  },
  {
    id: '4',
    icon: Zap,
    title: 'Lifetime Warranty',
    description:
      'All our products come with a lifetime warranty. If anything goes wrong, we\'ve got you covered.',
    color: 'teal',
  },
  {
    id: '5',
    icon: Lock,
    title: 'Full Access',
    description:
      'Receive complete account access including email credentials. Truly own what you purchase.',
    color: 'purple',
  },
  {
    id: '6',
    icon: Award,
    title: 'Verified Products',
    description:
      'Every product is thoroughly verified and tested before listing. Quality guaranteed.',
    color: 'teal',
  },
];

export default function Features() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="categories"
      ref={sectionRef}
      className="py-20 relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple/10 rounded-full blur-[128px]" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-teal/10 rounded-full blur-[128px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2
              className={`font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 transition-all duration-700 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
            >
              Why Choose <span className="text-gradient">GameVault?</span>
            </h2>
            <p
              className={`text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-100 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
            >
              We&apos;re committed to providing the best gaming experience with
              premium products and exceptional service.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              const isPurple = feature.color === 'purple';

              return (
                <div
                  key={feature.id}
                  className={`group relative p-6 rounded-2xl bg-dark-100 border border-white/10 hover:border-purple/50 transition-all duration-500 ${
                    isVisible
                      ? 'opacity-100 translate-y-0'
                      : 'opacity-0 translate-y-12'
                  }`}
                  style={{
                    transitionDelay: isVisible
                      ? `${200 + index * 100}ms`
                      : '0ms',
                  }}
                >
                  {/* Glow Effect */}
                  <div
                    className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${
                      isPurple ? 'bg-purple/5' : 'bg-teal/5'
                    }`}
                  />

                  {/* Icon */}
                  <div
                    className={`relative w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 ${
                      isPurple
                        ? 'bg-purple/20 text-purple group-hover:shadow-glow'
                        : 'bg-teal/20 text-teal group-hover:shadow-glow-teal'
                    }`}
                  >
                    <Icon className="w-7 h-7" />
                  </div>

                  {/* Content */}
                  <h3 className="relative font-display font-semibold text-xl text-white mb-2 group-hover:text-gradient transition-colors">
                    {feature.title}
                  </h3>
                  <p className="relative text-gray-400 text-sm leading-relaxed">
                    {feature.description}
                  </p>

                  {/* Connector Line (for desktop) */}
                  {index < features.length - 1 && (
                    <div className="hidden lg:block absolute -right-3 top-1/2 w-6 h-px bg-gradient-to-r from-white/20 to-transparent" />
                  )}
                </div>
              );
            })}
          </div>

          {/* Bottom CTA */}
          <div
            className={`mt-16 text-center transition-all duration-700 delay-700 ${
              isVisible
                ? 'opacity-100 translate-y-0'
                : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="inline-flex flex-col sm:flex-row items-center gap-4 p-6 rounded-2xl bg-gradient-to-r from-purple/10 to-teal/10 border border-white/10">
              <div className="text-center sm:text-left">
                <h3 className="font-display font-semibold text-white mb-1">
                  Ready to get started?
                </h3>
                <p className="text-sm text-gray-400">
                  Join thousands of satisfied gamers today.
                </p>
              </div>
              <a
                href="#products"
                className="px-6 py-3 rounded-xl bg-purple hover:bg-purple-700 text-white font-medium transition-all duration-300 hover:shadow-glow whitespace-nowrap"
              >
                Browse Store
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
