import { useState } from 'react';
import { Mail, MapPin, Phone, Send, Twitter, Instagram, Youtube, MessageCircle, Dribbble, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';

const footerLinks = {
  services: [
    { name: 'Social Media', href: '#services' },
    { name: 'Discord Services', href: '#services' },
    { name: 'Logo Design', href: '#services' },
    { name: 'Video Editing', href: '#services' },
    { name: 'Photo Editing', href: '#services' },
    { name: 'Architecture', href: '#services' },
  ],
  company: [
    { name: 'About Us', href: '#' },
    { name: 'Careers', href: '#' },
    { name: 'Blog', href: '#' },
    { name: 'Partners', href: '#' },
    { name: 'Press Kit', href: '#' },
  ],
  support: [
    { name: 'Help Center', href: '#faq' },
    { name: 'Contact Us', href: '#' },
    { name: 'Terms of Service', href: '#' },
    { name: 'Privacy Policy', href: '#' },
    { name: 'Refund Policy', href: '#' },
  ],
};

const socialLinks = [
  { name: 'Twitter', icon: Twitter, href: '#' },
  { name: 'Instagram', icon: Instagram, href: '#' },
  { name: 'YouTube', icon: Youtube, href: '#' },
  { name: 'Discord', icon: MessageCircle, href: '#' },
  { name: 'Dribbble', icon: Dribbble, href: '#' },
];

export default function Footer() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  return (
    <footer className="relative pt-24 pb-8 border-t border-white/10">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-dark-100 to-transparent pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Main Footer Content */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12 mb-16">
            {/* Brand Column */}
            <div className="col-span-2 md:col-span-4 lg:col-span-1">
              <a href="#home" className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12">
                  <img
                    src="/images/logo.png"
                    alt="Creteve"
                    className="w-full h-full object-contain"
                  />
                </div>
                <span className="font-display font-bold text-2xl text-gradient">
                  Creteve
                </span>
              </a>
              <p className="text-gray-400 text-sm mb-6 max-w-xs">
                The premier marketplace for creative digital services. 
                Connect with expert creators and bring your vision to life.
              </p>

              {/* Contact Info */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <Mail className="w-4 h-4 text-coral" />
                  <span>support@creteve.com</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <Phone className="w-4 h-4 text-coral" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <MapPin className="w-4 h-4 text-coral" />
                  <span>Global Service, Worldwide</span>
                </div>
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="font-display font-semibold text-white mb-4">
                Services
              </h3>
              <ul className="space-y-3">
                {footerLinks.services.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-sm text-gray-400 hover:text-coral transition-colors"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h3 className="font-display font-semibold text-white mb-4">
                Company
              </h3>
              <ul className="space-y-3">
                {footerLinks.company.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-sm text-gray-400 hover:text-coral transition-colors"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Support */}
            <div>
              <h3 className="font-display font-semibold text-white mb-4">
                Support
              </h3>
              <ul className="space-y-3">
                {footerLinks.support.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-sm text-gray-400 hover:text-coral transition-colors"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Newsletter */}
            <div className="col-span-2 md:col-span-4 lg:col-span-1">
              <h3 className="font-display font-semibold text-white mb-4">
                Newsletter
              </h3>
              <p className="text-sm text-gray-400 mb-4">
                Subscribe for exclusive deals, tips, and creative inspiration.
              </p>
              <form onSubmit={handleSubscribe} className="space-y-3">
                <div className="relative">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-dark-300 border-white/10 text-white placeholder:text-gray-500 pr-12 rounded-xl"
                  />
                  <button
                    type="submit"
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-gradient-to-r from-coral to-teal flex items-center justify-center transition-opacity hover:opacity-90"
                  >
                    <Send className="w-4 h-4 text-white" />
                  </button>
                </div>
                {isSubscribed && (
                  <p className="text-sm text-teal flex items-center gap-1">
                    <Sparkles className="w-4 h-4" />
                    Thanks for subscribing!
                  </p>
                )}
              </form>

              {/* Social Links */}
              <div className="mt-6">
                <p className="text-sm text-gray-400 mb-3">Follow us</p>
                <div className="flex gap-2">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={social.name}
                        href={social.href}
                        className="w-10 h-10 rounded-xl bg-white/5 hover:bg-coral/20 border border-white/10 hover:border-coral/50 flex items-center justify-center text-gray-400 hover:text-coral transition-all duration-300"
                        aria-label={social.name}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-gray-500 text-center md:text-left">
                &copy; {new Date().getFullYear()} Creteve. All rights reserved.
              </p>
              <div className="flex items-center gap-6">
                <a href="#" className="text-sm text-gray-500 hover:text-coral transition-colors">
                  Privacy Policy
                </a>
                <a href="#" className="text-sm text-gray-500 hover:text-coral transition-colors">
                  Terms of Service
                </a>
                <a href="#" className="text-sm text-gray-500 hover:text-coral transition-colors">
                  Cookie Policy
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
