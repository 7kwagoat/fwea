import { useRef, useEffect, useState } from 'react';
import { Search, FileText, MessageSquare, Download, Sparkles, ArrowRight } from 'lucide-react';

const steps = [
  {
    id: 1,
    icon: Search,
    title: 'Choose Your Service',
    description: 'Browse our extensive catalog of creative services and find the perfect match for your project needs.',
    color: 'coral',
  },
  {
    id: 2,
    icon: FileText,
    title: 'Submit Your Brief',
    description: 'Share your vision, requirements, and any reference materials with your assigned creator.',
    color: 'teal',
  },
  {
    id: 3,
    icon: MessageSquare,
    title: 'Review & Revise',
    description: 'Collaborate directly with your creator through unlimited revisions until you\'re 100% satisfied.',
    color: 'sky',
  },
  {
    id: 4,
    icon: Download,
    title: 'Receive Delivery',
    description: 'Get your final files in all required formats with full ownership rights.',
    color: 'gold',
  },
];

const colorClasses: Record<string, { bg: string; text: string; glow: string }> = {
  coral: { bg: 'bg-coral/20', text: 'text-coral', glow: 'shadow-glow' },
  teal: { bg: 'bg-teal/20', text: 'text-teal', glow: 'shadow-glow-teal' },
  sky: { bg: 'bg-sky/20', text: 'text-sky', glow: 'shadow-glow-sky' },
  gold: { bg: 'bg-gold/20', text: 'text-gold', glow: '' },
};

export default function HowItWorks() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-advance steps
  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % steps.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [isVisible]);

  return (
    <section
      id="how-it-works"
      ref={sectionRef}
      className="py-24 relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-coral/5 via-transparent to-teal/5 pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div 
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <Sparkles className="w-4 h-4 text-gold" />
              <span className="text-sm font-medium text-gray-300">Process</span>
            </div>
            
            <h2 
              className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              How It <span className="text-gradient">Works</span>
            </h2>
            
            <p 
              className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              Getting started is easy. Follow these simple steps to bring your creative vision to life.
            </p>
          </div>

          {/* Steps */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const colors = colorClasses[step.color];
              const isActive = activeStep === index;

              return (
                <div
                  key={step.id}
                  className={`relative transition-all duration-700 ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                  }`}
                  style={{ transitionDelay: `${300 + index * 150}ms` }}
                  onMouseEnter={() => setActiveStep(index)}
                >
                  {/* Connector Line */}
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-12 left-full w-full h-px">
                      <div className="relative w-full h-full bg-white/10">
                        <div 
                          className={`absolute inset-y-0 left-0 bg-gradient-to-r from-coral to-teal transition-all duration-500 ${
                            activeStep > index ? 'w-full' : 'w-0'
                          }`}
                        />
                      </div>
                      <ArrowRight className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    </div>
                  )}

                  {/* Card */}
                  <div 
                    className={`relative p-6 rounded-2xl border transition-all duration-500 ${
                      isActive 
                        ? `bg-dark-200 border-${step.color}/50 ${colors.glow}` 
                        : 'bg-dark-200/50 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {/* Step Number */}
                    <div className={`absolute -top-3 -left-3 w-8 h-8 rounded-full ${colors.bg} ${colors.text} flex items-center justify-center font-display font-bold text-sm`}>
                      {step.id}
                    </div>

                    {/* Icon */}
                    <div className={`w-14 h-14 rounded-xl ${colors.bg} ${colors.text} flex items-center justify-center mb-4 transition-transform duration-300 ${isActive ? 'scale-110' : ''}`}>
                      <Icon className="w-7 h-7" />
                    </div>

                    {/* Content */}
                    <h3 className="font-display text-xl font-semibold text-white mb-2">
                      {step.title}
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Progress Indicators */}
          <div className="flex justify-center gap-2 mt-12">
            {steps.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveStep(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  activeStep === index
                    ? 'w-8 bg-gradient-to-r from-coral to-teal'
                    : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
