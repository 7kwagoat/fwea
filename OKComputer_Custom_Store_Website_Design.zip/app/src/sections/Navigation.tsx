import { useState, useEffect } from 'react';
import { ShoppingCart, Menu, User, Zap } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';

const navLinks = [
  { name: 'Services', href: '#services' },
  { name: 'Portfolio', href: '#portfolio' },
  { name: 'How It Works', href: '#how-it-works' },
  { name: 'Pricing', href: '#pricing' },
  { name: 'FAQ', href: '#faq' },
];

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { totalItems, setIsCartOpen } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-500 ${
        isScrolled
          ? 'w-[95%] bg-dark-100/90 backdrop-blur-xl shadow-2xl'
          : 'w-[90%] bg-dark-100/50 backdrop-blur-md'
      } rounded-2xl border border-white/10`}
    >
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10">
              <img
                src="/images/logo.png"
                alt="Creteve"
                className="w-full h-full object-contain transition-all duration-300 group-hover:scale-110 group-hover:drop-shadow-[0_0_10px_rgba(255,107,107,0.5)]"
              />
            </div>
            <span className="font-display font-bold text-xl hidden sm:block">
              <span className="text-gradient">Creteve</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white transition-colors duration-300 rounded-lg hover:bg-white/5 relative group"
              >
                {link.name}
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-coral to-teal transition-all duration-300 group-hover:w-1/2" />
              </a>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all duration-300 group"
            >
              <ShoppingCart className="w-5 h-5 text-gray-400 group-hover:text-coral transition-colors" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-coral to-teal rounded-full flex items-center justify-center text-xs font-bold text-white animate-pulse">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Login Button - Desktop */}
            <Button
              variant="ghost"
              className="hidden sm:flex items-center gap-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl"
            >
              <User className="w-4 h-4" />
              Login
            </Button>

            {/* CTA Button - Desktop */}
            <Button className="hidden md:flex items-center gap-2 bg-gradient-to-r from-coral to-teal text-white font-medium rounded-xl hover:opacity-90 transition-opacity shadow-glow">
              <Zap className="w-4 h-4" />
              Get Started
            </Button>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <button className="lg:hidden p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                  <Menu className="w-5 h-5 text-gray-400" />
                </button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-full sm:w-80 bg-dark-100 border-white/10"
              >
                <div className="flex flex-col gap-2 mt-8">
                  {navLinks.map((link) => (
                    <a
                      key={link.name}
                      href={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="text-lg font-medium text-gray-300 hover:text-coral transition-colors px-4 py-3 rounded-xl hover:bg-white/5"
                    >
                      {link.name}
                    </a>
                  ))}
                  <hr className="border-white/10 my-4" />
                  <Button className="w-full bg-gradient-to-r from-coral to-teal text-white font-medium rounded-xl">
                    <User className="w-4 h-4 mr-2" />
                    Login
                  </Button>
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white font-medium rounded-xl">
                    <Zap className="w-4 h-4 mr-2" />
                    Get Started
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
