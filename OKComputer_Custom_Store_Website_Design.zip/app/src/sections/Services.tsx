import { useRef, useEffect, useState } from 'react';
import { ArrowRight, TrendingUp, MessageCircle, Palette, Film, Camera, Home, Box, Sparkles } from 'lucide-react';
import { serviceCategories } from '@/data/services';
import { use3DTilt } from '@/hooks/use3DTilt';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  TrendingUp,
  MessageCircle,
  Palette,
  Film,
  Camera,
  Home,
  Box,
  Sparkles,
};

function ServiceCard({ category, index }: { category: typeof serviceCategories[0]; index: number }) {
  const { ref, tilt, handlers } = use3DTilt(8);
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const Icon = iconMap[category.icon] || Sparkles;
  
  const getColorClass = (color: string) => {
    switch (color) {
      case 'coral':
        return 'from-[#FF6B6B] to-[#FF8E8E]';
      case 'teal':
        return 'from-[#4ECDC4] to-[#6EE0D8]';
      case 'sky':
        return 'from-[#45B7D1] to-[#6EC3E0]';
      case 'gold':
        return 'from-[#FFD700] to-[#FFE44D]';
      default:
        return 'from-[#FF6B6B] to-[#4ECDC4]';
    }
  };
  
  const colorClass = getColorClass(category.color);

  return (
    <div
      ref={cardRef}
      className={`transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div
        ref={ref}
        {...handlers}
        className="group relative h-full cursor-pointer"
        style={{
          perspective: '1000px',
        }}
      >
        <div
          className="relative h-full rounded-2xl overflow-hidden bg-dark-200 border border-white/10 transition-all duration-300 group-hover:border-coral/50"
          style={{
            transform: `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg) scale(${tilt.scale})`,
            transformStyle: 'preserve-3d',
            transition: 'transform 0.15s ease-out',
          }}
        >
          {/* Image */}
          <div className="relative h-48 overflow-hidden">
            <img
              src={category.image}
              alt={category.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-200 via-dark-200/50 to-transparent" />
            
            {/* Icon Badge */}
            <div className={`absolute top-4 left-4 w-12 h-12 rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center shadow-lg animate-float-slow`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            <h3 className="font-display text-xl font-semibold text-white mb-2 group-hover:text-gradient transition-colors">
              {category.name}
            </h3>
            <p className="text-gray-400 text-sm mb-4 line-clamp-2">
              {category.description}
            </p>
            
            {/* CTA */}
            <div className="flex items-center gap-2 text-coral text-sm font-medium group/link">
              <span>Explore</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover/link:translate-x-1" />
            </div>
          </div>

          {/* Hover Glow */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
            <div className={`absolute inset-0 bg-gradient-to-br ${colorClass} opacity-5`} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Services() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="py-24 relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-coral/10 rounded-full blur-[200px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-teal/10 rounded-full blur-[200px] pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div 
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <Sparkles className="w-4 h-4 text-coral" />
              <span className="text-sm font-medium text-gray-300">Our Services</span>
            </div>
            
            <h2 
              className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              What We <span className="text-gradient">Create</span>
            </h2>
            
            <p 
              className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              From social media growth to architectural visualization, our expert creators 
              deliver exceptional results across every digital discipline.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {serviceCategories.map((category, index) => (
              <ServiceCard key={category.id} category={category} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
