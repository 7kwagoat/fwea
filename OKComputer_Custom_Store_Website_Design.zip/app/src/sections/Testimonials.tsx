import { useState, useRef, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote, Sparkles } from 'lucide-react';
import { reviews } from '@/data/services';

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-play
  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % reviews.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isVisible]);

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % reviews.length);
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-sky/5 to-transparent pointer-events-none" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div 
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <Sparkles className="w-4 h-4 text-coral" />
              <span className="text-sm font-medium text-gray-300">Testimonials</span>
            </div>
            
            <h2 
              className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              What Our <span className="text-gradient">Clients Say</span>
            </h2>
          </div>

          {/* Testimonials Carousel */}
          <div 
            className={`relative transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {/* Main Card */}
            <div className="relative max-w-4xl mx-auto">
              {/* Quote Icon */}
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-14 h-14 rounded-full bg-gradient-to-br from-coral to-teal flex items-center justify-center z-10">
                <Quote className="w-6 h-6 text-white" />
              </div>

              {/* Card */}
              <div className="relative bg-dark-200 rounded-3xl p-8 sm:p-12 border border-white/10 overflow-hidden">
                {/* Background Glow */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-coral/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal/10 rounded-full blur-[100px]" />

                {/* Content */}
                <div className="relative">
                  {reviews.map((review, index) => (
                    <div
                      key={review.id}
                      className={`transition-all duration-500 ${
                        index === activeIndex
                          ? 'opacity-100 translate-x-0'
                          : 'opacity-0 absolute inset-0 translate-x-8'
                      }`}
                    >
                      {/* Rating */}
                      <div className="flex justify-center gap-1 mb-6">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < review.rating
                                ? 'text-gold fill-gold'
                                : 'text-gray-600'
                            }`}
                          />
                        ))}
                      </div>

                      {/* Comment */}
                      <p className="text-center text-lg sm:text-xl text-gray-300 mb-8 leading-relaxed">
                        &ldquo;{review.comment}&rdquo;
                      </p>

                      {/* Author */}
                      <div className="flex items-center justify-center gap-4">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-coral to-teal flex items-center justify-center text-white font-bold text-xl">
                          {review.avatar}
                        </div>
                        <div className="text-left">
                          <div className="font-display font-semibold text-white text-lg">
                            {review.name}
                          </div>
                          <div className="text-sm text-coral">
                            {review.service}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 sm:-translate-x-8 w-12 h-12 rounded-full bg-dark-200 border border-white/10 hover:border-coral/50 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300 hover:shadow-glow"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 sm:translate-x-8 w-12 h-12 rounded-full bg-dark-200 border border-white/10 hover:border-coral/50 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300 hover:shadow-glow"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Dots */}
            <div className="flex justify-center gap-2 mt-8">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === activeIndex
                      ? 'w-8 bg-gradient-to-r from-coral to-teal'
                      : 'bg-white/20 hover:bg-white/40'
                  }`}
                />
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-12 max-w-lg mx-auto">
              <div className="text-center p-4 rounded-xl bg-dark-200 border border-white/10">
                <div className="font-display text-2xl font-bold text-coral">4.9</div>
                <div className="text-xs text-gray-500">Average Rating</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-dark-200 border border-white/10">
                <div className="font-display text-2xl font-bold text-teal">2K+</div>
                <div className="text-xs text-gray-500">Reviews</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-dark-200 border border-white/10">
                <div className="font-display text-2xl font-bold text-sky">98%</div>
                <div className="text-xs text-gray-500">Recommend</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
