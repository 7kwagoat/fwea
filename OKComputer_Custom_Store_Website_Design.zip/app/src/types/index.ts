export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  badge?: string;
  rating: number;
  reviews: number;
  features?: string[];
}

export interface CartItem extends Service {
  quantity: number;
}

export interface Review {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  service: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  image: string;
  icon: string;
  color: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  image: string;
  author: string;
}
